package com.junaid.autoclose

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc
import java.io.File

object TemplateStore {

    private const val ASSET_DIR = "templates"

    fun dir(ctx: Context): File = File(ctx.filesDir, "templates").apply { mkdirs() }

    fun userCount(ctx: Context): Int = dir(ctx).listFiles()?.size ?: 0

    fun bundledCount(ctx: Context): Int = ctx.assets.list(ASSET_DIR)?.size ?: 0

    fun clearUser(ctx: Context) {
        dir(ctx).listFiles()?.forEach { it.delete() }
    }

    /** OpenCV চালু হওয়ার পরে ডাকতে হবে */
    fun load(ctx: Context): List<IconTemplate> {
        val out = mutableListOf<IconTemplate>()

        // ১) কোডে আঁকা আইকন
        for ((name, bmp) in BuiltinIcons.all()) {
            out += toTemplate(name, bmp, Kind.BUILTIN)
        }

        // ২) অ্যাপের সঙ্গে দেওয়া ছবি (app/src/main/assets/templates)
        //    ফাইলের নাম "icon_" দিয়ে শুরু হলে ছোট আইকন, "button_" দিয়ে শুরু হলে বড় বাটন
        ctx.assets.list(ASSET_DIR)?.sorted()?.forEach { file ->
            val bmp = ctx.assets.open("$ASSET_DIR/$file").use { BitmapFactory.decodeStream(it) }
                ?: return@forEach
            // বড় বাটনে লেখা থাকে, সাইজ সামান্য ভুল হলেই মিল কমে যায়, তাই ধাপ বেশি
            out += if (file.startsWith("button_")) {
                toTemplate(file, bmp, Kind.RANGE, 0.45, 0.95, steps = 32)
            } else {
                toTemplate(file, bmp, Kind.RANGE, 0.03, 0.14, steps = 12)
            }
        }

        // ৩) অ্যাপ থেকে ইউজারের যোগ করা ছবি
        dir(ctx).listFiles()?.sortedBy { it.name }?.forEach { f ->
            BitmapFactory.decodeFile(f.path)?.let { out += toTemplate(f.name, it, Kind.NATIVE) }
        }
        return out
    }

    private fun toTemplate(
        name: String,
        src: Bitmap,
        kind: Kind,
        minFrac: Double = 0.0,
        maxFrac: Double = 0.0,
        steps: Int = 8
    ): IconTemplate {
        // স্বচ্ছ অংশ সাদা করে নেওয়া হয়
        val flat = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(flat)
        c.drawColor(Color.WHITE)
        c.drawBitmap(src, 0f, 0f, null)

        val rgba = Mat()
        Utils.bitmapToMat(flat, rgba)
        val gray = Mat()
        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        rgba.release()
        return IconTemplate(name, gray, kind, minFrac, maxFrac, steps)
    }
}
