package com.junaid.autoclose

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val FILE = "autoclose"

    const val ENABLED = "enabled"
    const val THRESHOLD = "threshold"          // 40..95 (শতাংশ)
    const val INTERVAL = "interval_ms"          // 500..5000

    // কোন ধরনের লক্ষ্য খুঁজবে
    const val G_SKIP = "g_skip"                // অ্যাপের সঙ্গে দেওয়া ছোট আইকন (>>)
    const val G_BUTTON = "g_button"            // অ্যাপের সঙ্গে দেওয়া বড় বাটনের ছবি
    const val G_OCR = "g_ocr"                  // স্ক্রিনের লেখা পড়ে বাটন ধরা
    const val G_NODE = "g_node"                // বাটনের নাম (accessibility) দেখে ধরা
    const val G_BUILTIN = "g_builtin"          // কোডে আঁকা × / >> আইকন
    const val G_USER = "g_user"                // ইউজারের নিজের যোগ করা আইকন

    const val PHRASES = "phrases"
    const val DEFAULT_PHRASES = "collect gem"

    const val BUBBLE = "bubble"
    const val BUBBLE_X = "bubble_x"
    const val BUBBLE_Y = "bubble_y"
    const val DEBUG_TOAST = "debug_toast"
    const val TEMPLATES_VERSION = "templates_version"

    fun of(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
}
