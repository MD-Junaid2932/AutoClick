package com.junaid.autoclose

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.opencv.android.OpenCVLoader
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * স্ক্রিন দেখে (ক) আইকন/বাটনের ছবি মিলিয়ে, (খ) বাটনের লেখা পড়ে, (গ) বাটনের নাম দেখে
 * লক্ষ্য খুঁজে বের করে এবং সেখানে ট্যাপ করে।
 */
class AutoCloseService : AccessibilityService() {

    companion object {
        private const val TAG = "AutoClose"
        private const val CLICK_COOLDOWN_MS = 1500L
        private const val EVENT_DEBOUNCE_MS = 300L
        private val BUILTIN_NAMES = setOf("close", "dismiss", "×", "✕", "✖")
    }

    private val handler = Handler(Looper.getMainLooper())
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private lateinit var prefs: SharedPreferences

    private var ui: FloatingUi? = null
    private var cvReady = false
    private var matcher: IconMatcher? = null
    private var loadedVersion = -1
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    @Volatile
    private var busy = false
    private var overlayRect: Rect? = null
    private var lastClickAt = -100000L
    private var lastClickName = ""
    private var clickCount = 0

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        onPrefChanged(key)
    }

    private val host = object : UiHost {
        override fun onScanNow() {
            triggerScan(true)
        }

        override fun onSaveShot() {
            saveShot()
        }
    }

    private val nodeScan = Runnable {
        try {
            if (prefs.getBoolean(Prefs.ENABLED, true)) scanNodeTree()
        } catch (e: Throwable) {
            Log.e(TAG, "node scan", e)
        }
    }

    private val loop = object : Runnable {
        override fun run() {
            try {
                periodic()
            } catch (e: Throwable) {
                Log.e(TAG, "loop", e)
            }
            handler.postDelayed(this, prefs.getInt(Prefs.INTERVAL, 1500).toLong())
        }
    }

    // ---------- জীবনচক্র ----------

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = Prefs.of(this)
        cvReady = try {
            OpenCVLoader.initLocal()
        } catch (e: Throwable) {
            false
        }
        prefs.registerOnSharedPreferenceChangeListener(prefListener)

        ui?.hide()
        val u = FloatingUi(this, host)
        ui = u
        u.setEnabledState(prefs.getBoolean(Prefs.ENABLED, true))
        if (prefs.getBoolean(Prefs.BUBBLE, true)) u.show()
        if (!cvReady) {
            u.setWarn(true)
            u.setStatus("⚠ OpenCV লোড হয়নি (ছবি মেলানো কাজ করবে না)")
        }

        handler.removeCallbacks(loop)
        handler.postDelayed(loop, 1000)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        ui?.hide()
        if (this::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        worker.shutdownNow()
        try {
            recognizer.close()
        } catch (e: Throwable) {
        }
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!this::prefs.isInitialized) return
        if (event?.packageName?.toString() == packageName) return
        handler.removeCallbacks(nodeScan)
        handler.postDelayed(nodeScan, EVENT_DEBOUNCE_MS)
    }

    private fun onPrefChanged(key: String?) {
        when (key) {
            Prefs.BUBBLE -> {
                if (prefs.getBoolean(Prefs.BUBBLE, true)) ui?.show() else ui?.hide()
            }
            Prefs.ENABLED -> ui?.setEnabledState(prefs.getBoolean(Prefs.ENABLED, true))
        }
    }

    // ---------- সময়ে সময়ে স্ক্যান ----------

    private fun screenOn(): Boolean =
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive

    private fun canClickNow(): Boolean =
        SystemClock.uptimeMillis() - lastClickAt >= CLICK_COOLDOWN_MS

    private fun periodic() {
        if (!prefs.getBoolean(Prefs.ENABLED, true)) return
        if (!screenOn()) return
        if (scanNodeTree()) return
        triggerScan(false)
    }

    private fun normAlnum(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    private fun phrases(): List<String> {
        val raw = prefs.getString(Prefs.PHRASES, Prefs.DEFAULT_PHRASES) ?: ""
        return raw.split(',', '\n').map { normAlnum(it) }.filter { it.length >= 3 }
    }

    // ---------- (গ) বাটনের নাম দেখে ----------

    private fun scanNodeTree(): Boolean {
        if (!prefs.getBoolean(Prefs.G_NODE, true) && !prefs.getBoolean(Prefs.G_BUILTIN, false)) return false
        if (!canClickNow()) return false
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() == packageName) return false

        val ph = if (prefs.getBoolean(Prefs.G_NODE, true)) phrases() else emptyList()
        val builtin = prefs.getBoolean(Prefs.G_BUILTIN, false)
        val hit = findNode(root, 0, ph, builtin) ?: return false

        lastClickAt = SystemClock.uptimeMillis()
        clickCount++
        lastClickName = "নাম দেখে"
        var n: AccessibilityNodeInfo? = hit
        while (n != null) {
            if (n.isClickable && n.isEnabled && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
        }
        val r = Rect()
        hit.getBoundsInScreen(r)
        tap(r.centerX(), r.centerY())
        return true
    }

    private fun findNode(
        node: AccessibilityNodeInfo,
        depth: Int,
        ph: List<String>,
        builtin: Boolean
    ): AccessibilityNodeInfo? {
        if (depth > 40) return null
        if (node.isVisibleToUser) {
            if (matches(node.text, ph, builtin) || matches(node.contentDescription, ph, builtin)) return node
        }
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            val f = findNode(c, depth + 1, ph, builtin)
            if (f != null) return f
        }
        return null
    }

    private fun matches(cs: CharSequence?, ph: List<String>, builtin: Boolean): Boolean {
        if (cs == null) return false
        val raw = cs.toString().trim().lowercase()
        if (raw.isEmpty()) return false
        if (builtin && raw in BUILTIN_NAMES) return true
        val n = normAlnum(raw)
        if (n.length > 60) return false
        return ph.any { n.contains(it) }
    }

    // ---------- (ক)(খ) স্ক্রিনের ছবি নিয়ে ----------

    private fun triggerScan(manual: Boolean) {
        if (busy) return
        if (!manual && !canClickNow()) return
        val allowClick = prefs.getBoolean(Prefs.ENABLED, true)
        busy = true
        overlayRect = ui?.currentRect()

        try {
        captureFrame { bmp, src ->
            if (bmp == null) {
                handler.post {
                    ui?.setWarn(true)
                    ui?.setStatus("⚠ স্ক্রিনের ছবি পাওয়া যায়নি\n$src")
                }
                busy = false
                return@captureFrame
            }
            worker.execute { process(bmp, src, allowClick) }
        }
        } catch (e: Throwable) {
            Log.e(TAG, "capture start failed", e)
            busy = false
        }
    }

    /** ছবি পেলে onResult ডাকে (যেকোনো থ্রেডে) */
    private fun captureFrame(onResult: (Bitmap?, String) -> Unit) {
        val proj = CaptureBridge.service
        if (proj != null) {
            worker.execute { onResult(proj.grab(), "স্ক্রিন-ক্যাপচার") }
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    var bmp: Bitmap? = null
                    try {
                        val hw = result.hardwareBuffer
                        val hwBmp = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                        bmp = hwBmp?.copy(Bitmap.Config.ARGB_8888, true)
                        hwBmp?.recycle()
                        hw.close()
                    } catch (e: Throwable) {
                        Log.e(TAG, "screenshot convert", e)
                    }
                    onResult(bmp, "Accessibility স্ক্রিনশট")
                }

                override fun onFailure(errorCode: Int) {
                    onResult(null, "Accessibility স্ক্রিনশট ব্যর্থ (কোড $errorCode)")
                }
            })
            return
        }
        onResult(null, "এই ফোনে (Android 10 বা পুরোনো) অ্যাপ খুলে \"স্ক্রিন-ক্যাপচার চালু করুন\" চাপুন")
    }

    private fun isBlank(bmp: Bitmap): Boolean {
        var bright = 0
        val w = bmp.width
        val h = bmp.height
        for (i in 1..15) {
            for (j in 1..25) {
                val p = bmp.getPixel(w * i / 16, h * j / 26)
                val lum = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3
                if (lum > 12) bright++
            }
        }
        return bright == 0
    }

    private fun maskOverlay(bmp: Bitmap) {
        val r = overlayRect ?: return
        val paint = Paint()
        paint.color = Color.rgb(128, 128, 128)
        Canvas(bmp).drawRect(r, paint)
    }

    private fun process(bmp: Bitmap, src: String, allowClick: Boolean) {
        val t0 = SystemClock.uptimeMillis()
        try {
            val blank = isBlank(bmp)
            maskOverlay(bmp)

            val threshold = prefs.getInt(Prefs.THRESHOLD, 70) / 100.0

            val version = prefs.getInt(Prefs.TEMPLATES_VERSION, 0)
            var m: IconMatcher? = null
            if (cvReady) {
                m = matcher
                if (m == null || version != loadedVersion) {
                    matcher?.release()
                    m = IconMatcher(TemplateStore.load(this))
                    matcher = m
                    loadedVersion = version
                }
            }

            val groups = HashSet<String>()
            if (prefs.getBoolean(Prefs.G_SKIP, true)) groups.add("skip")
            if (prefs.getBoolean(Prefs.G_BUTTON, true)) groups.add("button")
            if (prefs.getBoolean(Prefs.G_BUILTIN, false)) groups.add("builtin")
            if (prefs.getBoolean(Prefs.G_USER, true)) groups.add("user")

            val cands: List<Candidate> =
                if (m != null) m.scan(bmp, resources.displayMetrics.density, groups) else emptyList()

            var ocr: Candidate? = null
            val useOcr = prefs.getBoolean(Prefs.G_OCR, true)
            if (useOcr) ocr = findByOcr(bmp)

            val hits = cands.filter { it.score >= threshold }
            val pick: Candidate? = ocr ?: hits.maxByOrNull { it.score }

            val ms = SystemClock.uptimeMillis() - t0
            val text = buildStatus(src, ms, blank, groups, cands, threshold, useOcr, ocr)

            handler.post {
                ui?.setStatus(text)
                ui?.setWarn(blank || !cvReady)
                if (pick != null && allowClick) doClick(pick)
            }
        } catch (e: Throwable) {
            Log.e(TAG, "process", e)
            handler.post { ui?.setStatus("⚠ ত্রুটি: ${e.javaClass.simpleName}") }
        } finally {
            bmp.recycle()
            busy = false
        }
    }

    /** স্ক্রিনের লেখা পড়ে নির্ধারিত বাক্য (যেমন "collect gem") খোঁজে */
    private fun findByOcr(bmp: Bitmap): Candidate? {
        val ph = phrases()
        if (ph.isEmpty()) return null
        return try {
            val text = Tasks.await(recognizer.process(InputImage.fromBitmap(bmp, 0)))
            var found: Candidate? = null
            for (block in text.textBlocks) {
                for (line in block.lines) {
                    val n = normAlnum(line.text)
                    for (p in ph) {
                        val box = line.boundingBox
                        if (box != null && n.contains(p) && found == null) {
                            found = Candidate("লেখা: $p", "ocr", 1.0, box.centerX(), box.centerY())
                        }
                    }
                }
            }
            found
        } catch (e: Exception) {
            Log.e(TAG, "ocr", e)
            null
        }
    }

    private fun fmt(label: String, s: Double?, th: Double): String {
        if (s == null) return "$label: —"
        val mark = if (s >= th) " ✅" else ""
        return label + ": " + String.format("%.2f", s) + mark
    }

    private fun best(c: List<Candidate>, group: String): Double? =
        c.filter { it.group == group }.maxOfOrNull { it.score }

    private fun buildStatus(
        src: String,
        ms: Long,
        blank: Boolean,
        groups: Set<String>,
        cands: List<Candidate>,
        th: Double,
        useOcr: Boolean,
        ocr: Candidate?
    ): String {
        val sb = StringBuilder()
        sb.append("ক্যাপচার: ").append(src).append(" (").append(ms).append("ms)\n")
        if (blank) sb.append("⚠ স্ক্রিন কালো আসছে — অ্যাপটি স্ক্রিনশট আটকে রেখেছে\n")
        if (!cvReady) sb.append("⚠ OpenCV লোড হয়নি\n")
        if ("skip" in groups) sb.append(fmt("আইকন >>", best(cands, "skip"), th)).append('\n')
        if ("button" in groups) sb.append(fmt("বাটন (ছবি)", best(cands, "button"), th)).append('\n')
        if ("builtin" in groups) sb.append(fmt("বিল্ট-ইন", best(cands, "builtin"), th)).append('\n')
        if ("user" in groups) sb.append(fmt("আমার আইকন", best(cands, "user"), th)).append('\n')
        if (useOcr) sb.append("বাটন (লেখা): ").append(if (ocr != null) "পেয়েছি ✅" else "নেই").append('\n')
        if (clickCount > 0) {
            val sec = (SystemClock.uptimeMillis() - lastClickAt) / 1000
            sb.append("ক্লিক: মোট ").append(clickCount).append(", শেষ ").append(sec)
                .append(" সে. আগে (").append(lastClickName).append(")")
        } else {
            sb.append("এখনো ক্লিক হয়নি")
        }
        return sb.toString()
    }

    // ---------- ট্যাপ ----------

    private fun doClick(c: Candidate) {
        val r = overlayRect
        if (r != null && r.contains(c.x, c.y)) return
        if (!canClickNow()) return
        lastClickAt = SystemClock.uptimeMillis()
        lastClickName = c.name
        clickCount++
        tap(c.x, c.y)
        if (prefs.getBoolean(Prefs.DEBUG_TOAST, false)) {
            Toast.makeText(this, "ক্লিক: ${c.name} (${String.format("%.2f", c.score)})", Toast.LENGTH_SHORT).show()
        }
    }

    private fun tap(x: Int, y: Int) {
        val path = Path()
        path.moveTo(x.toFloat(), y.toFloat())
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 90))
            .build()
        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCancelled(gestureDescription: GestureDescription?) {
                clickNodeAt(x, y)
            }
        }, handler)
        if (!ok) clickNodeAt(x, y)
    }

    /** ট্যাপ ব্যর্থ হলে: ওই জায়গার ক্লিকযোগ্য এলিমেন্টে সরাসরি ক্লিক */
    private fun clickNodeAt(x: Int, y: Int) {
        val root = rootInActiveWindow ?: return
        val n = deepestClickableAt(root, x, y, 0) ?: return
        n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun deepestClickableAt(node: AccessibilityNodeInfo, x: Int, y: Int, depth: Int): AccessibilityNodeInfo? {
        if (depth > 40) return null
        val r = Rect()
        node.getBoundsInScreen(r)
        if (!r.contains(x, y)) return null
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            val f = deepestClickableAt(c, x, y, depth + 1)
            if (f != null) return f
        }
        return if (node.isClickable && node.isEnabled) node else null
    }

    // ---------- স্ক্রিনশট সেভ (সমস্যা ধরার জন্য) ----------

    private fun saveShot() {
        ui?.setVisible(false)
        handler.postDelayed({
            captureFrame { bmp, src ->
                handler.post { ui?.setVisible(true) }
                if (bmp == null) {
                    handler.post { ui?.setStatus("সেভ ব্যর্থ: $src") }
                    return@captureFrame
                }
                worker.execute {
                    val ok = savePng(bmp)
                    bmp.recycle()
                    handler.post {
                        ui?.setStatus(
                            if (ok) "স্ক্রিনশট সেভ হয়েছে (Pictures/AutoClose)"
                            else "সেভ ব্যর্থ (Android 10+ লাগে)"
                        )
                    }
                }
            }
        }, 500)
    }

    private fun savePng(bmp: Bitmap): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        return try {
            val v = ContentValues()
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "autoclose_" + System.currentTimeMillis() + ".png")
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AutoClose")
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
            if (uri == null) {
                false
            } else {
                contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}
