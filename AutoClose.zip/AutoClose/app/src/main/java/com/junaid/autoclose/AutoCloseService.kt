package com.junaid.autoclose

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import org.opencv.android.OpenCVLoader
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * প্রতি ২ সেকেন্ডে স্ক্রিনশট নিয়ে ক্লোজ (×) / স্কিপ (>>) আইকনের ছবি খোঁজে,
 * পেলে ঠিক সেখানে ট্যাপ করে। (Android 11+ লাগে)
 *
 * বাড়তি সুবিধা: কোনো বাটনের accessibility নাম "Close"/"Dismiss" হলে
 * সেটা স্ক্রিনশট ছাড়াই সরাসরি চাপে।
 */
class AutoCloseService : AccessibilityService() {

    companion object {
        const val PREFS = "autoclose"
        const val KEY_ENABLED = "enabled"
        const val KEY_THRESHOLD = "threshold"   // ৫০–৯৫ (শতাংশ)
        const val KEY_VERSION = "templates_version"
        const val KEY_DEBUG = "debug_toast"

        private val NODE_TARGETS = setOf("close", "dismiss", "×", "✕", "✖")

        // এই লেখা নামের মধ্যে থাকলেই সেই বাটনে চাপে (ওয়েব/অ্যাপের বাটনে লেখা পাওয়া গেলে ছবি ছাড়াই ধরে)
        private val NODE_CONTAINS = listOf("collect gem")

        private const val CLICK_COOLDOWN_MS = 1500L
        private const val SCAN_INTERVAL_MS = 2000L
        private const val EVENT_DEBOUNCE_MS = 300L
        private const val TAG = "AutoClose"
    }

    private val handler = Handler(Looper.getMainLooper())
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()

    private var cvReady = false
    private var matcher: IconMatcher? = null
    private var loadedVersion = -1

    @Volatile private var busy = false
    private var lastClickAt = 0L

    private val nodeScan = Runnable { scanNodeTree() }

    private val loop = object : Runnable {
        override fun run() {
            if (isEnabled()) scanByScreenshot()
            handler.postDelayed(this, SCAN_INTERVAL_MS)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        cvReady = OpenCVLoader.initLocal()
        if (!cvReady) Log.e(TAG, "OpenCV লোড হয়নি")
        handler.postDelayed(loop, SCAN_INTERVAL_MS)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        worker.shutdownNow()
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!isEnabled()) return
        if (event?.packageName == packageName) return
        handler.removeCallbacks(nodeScan)
        handler.postDelayed(nodeScan, EVENT_DEBOUNCE_MS)
    }

    private fun prefs() = getSharedPreferences(PREFS, MODE_PRIVATE)
    private fun isEnabled() = prefs().getBoolean(KEY_ENABLED, true)
    private fun canClickNow() = System.currentTimeMillis() - lastClickAt >= CLICK_COOLDOWN_MS
    private fun norm(s: CharSequence?) = s?.toString()?.trim()?.lowercase() ?: ""

    private fun matchesName(s: String): Boolean =
        s.isNotEmpty() && (s in NODE_TARGETS || NODE_CONTAINS.any { s.contains(it) })

    // ---------- accessibility নাম ধরে ----------

    private fun scanNodeTree() {
        if (!canClickNow()) return
        val root = rootInActiveWindow ?: return
        if (root.packageName == packageName) return
        val hit = findNode(root, 0) ?: return
        lastClickAt = System.currentTimeMillis()
        var n: AccessibilityNodeInfo? = hit
        while (n != null) {
            if (n.isClickable && n.isEnabled &&
                n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            ) return
            n = n.parent
        }
        val r = Rect()
        hit.getBoundsInScreen(r)
        tap(r.centerX(), r.centerY())
    }

    private fun findNode(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 40) return null
        if (node.isVisibleToUser && (matchesName(norm(node.text)) || matchesName(norm(node.contentDescription)))) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findNode(child, depth + 1)?.let { return it }
        }
        return null
    }

    // ---------- স্ক্রিনশট + আইকন ম্যাচিং ----------

    private fun scanByScreenshot() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        if (!cvReady || busy || !canClickNow()) return
        // স্ক্রিন বন্ধ থাকলে ব্যাটারি বাঁচাতে স্ক্যান করে না
        if (!(getSystemService(POWER_SERVICE) as PowerManager).isInteractive) return
        if (rootInActiveWindow?.packageName == packageName) return
        busy = true

        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    val hw = result.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, false)
                    hw.close()
                    if (bmp == null) {
                        busy = false
                        return
                    }

                    val p = prefs()
                    val threshold = p.getInt(KEY_THRESHOLD, 70) / 100.0
                    val version = p.getInt(KEY_VERSION, 0)
                    val density = resources.displayMetrics.density

                    worker.execute {
                        try {
                            var m = matcher
                            if (m == null || version != loadedVersion) {
                                m = IconMatcher(TemplateStore.load(this@AutoCloseService))
                                matcher = m
                                loadedVersion = version
                            }
                            val hit = m.find(bmp, density, threshold)
                            if (hit != null) {
                                handler.post {
                                    lastClickAt = System.currentTimeMillis()
                                    tap(hit.x, hit.y)
                                    if (prefs().getBoolean(KEY_DEBUG, false)) {
                                        Toast.makeText(
                                            this@AutoCloseService,
                                            "ক্লিক: ${hit.name} (${"%.2f".format(hit.score)})",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            }
                        } catch (e: Throwable) {
                            Log.e(TAG, "ম্যাচিং ব্যর্থ", e)
                        } finally {
                            bmp.recycle()
                            busy = false
                        }
                    }
                }

                override fun onFailure(errorCode: Int) {
                    busy = false
                }
            }
        )
    }

    // ---------- ট্যাপ ----------

    private fun tap(x: Int, y: Int) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
