package com.junaid.autoclose

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {

    private val reqPick = 1

    private lateinit var statusText: TextView
    private lateinit var thresholdText: TextView
    private lateinit var userIconsText: TextView

    private val prefs by lazy { getSharedPreferences(AutoCloseService.PREFS, MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        thresholdText = findViewById(R.id.thresholdText)
        userIconsText = findViewById(R.id.userIconsText)

        findViewById<Switch>(R.id.switchEnabled).apply {
            isChecked = prefs.getBoolean(AutoCloseService.KEY_ENABLED, true)
            setOnCheckedChangeListener { _, c ->
                prefs.edit().putBoolean(AutoCloseService.KEY_ENABLED, c).apply()
            }
        }

        findViewById<Switch>(R.id.switchDebug).apply {
            isChecked = prefs.getBoolean(AutoCloseService.KEY_DEBUG, false)
            setOnCheckedChangeListener { _, c ->
                prefs.edit().putBoolean(AutoCloseService.KEY_DEBUG, c).apply()
            }
        }

        // সংবেদনশীলতা: ৫০–৯৫
        val seek = findViewById<SeekBar>(R.id.seekThreshold)
        val saved = prefs.getInt(AutoCloseService.KEY_THRESHOLD, 70)
        seek.progress = saved - 50
        showThreshold(saved)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = progress + 50
                prefs.edit().putInt(AutoCloseService.KEY_THRESHOLD, v).apply()
                showThreshold(v)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnAddIcon).setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(i, reqPick)
        }

        findViewById<Button>(R.id.btnClearIcons).setOnClickListener {
            TemplateStore.clearUser(this)
            bumpVersion()
            refreshUserIcons()
        }
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        statusText.text = if (enabled.contains(packageName))
            "সার্ভিস: চালু আছে ✅" else "সার্ভিস: বন্ধ ❌ (নিচের বাটন দিয়ে চালু করুন)"
        refreshUserIcons()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqPick || resultCode != RESULT_OK) return
        val uri = data?.data ?: return

        val bmp: Bitmap? = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        if (bmp == null) {
            Toast.makeText(this, "ছবি পড়া যায়নি", Toast.LENGTH_SHORT).show()
            return
        }
        if (maxOf(bmp.width, bmp.height) > 300) {
            Toast.makeText(
                this,
                "ছবিটা অনেক বড়। শুধু আইকনটুকু টাইট করে ক্রপ করে দিন।",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val f = File(TemplateStore.dir(this), "user_${System.currentTimeMillis()}.png")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bumpVersion()
        refreshUserIcons()
        Toast.makeText(this, "আইকন যোগ হয়েছে", Toast.LENGTH_SHORT).show()
    }

    private fun bumpVersion() {
        prefs.edit().putInt(
            AutoCloseService.KEY_VERSION,
            prefs.getInt(AutoCloseService.KEY_VERSION, 0) + 1
        ).apply()
    }

    private fun showThreshold(v: Int) {
        thresholdText.text = "সংবেদনশীলতা (মিলের সীমা): $v%"
    }

    private fun refreshUserIcons() {
        userIconsText.text = "অ্যাপের সঙ্গে দেওয়া আপনার ছবি: ${TemplateStore.bundledCount(this)} টি\n" +
            "পরে যোগ করা আইকন: ${TemplateStore.userCount(this)} টি\n" +
            "(বিল্ট-ইন ৭ ধরনের × / >> আইকনও সবসময় থাকে)"
    }
}
