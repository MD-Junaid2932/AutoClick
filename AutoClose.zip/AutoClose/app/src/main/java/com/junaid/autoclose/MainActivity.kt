package com.junaid.autoclose

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {

    private val reqPick = 1
    private val reqProjection = 2

    private lateinit var statusText: TextView
    private lateinit var infoText: TextView
    private lateinit var userIconsText: TextView
    private lateinit var phrasesEdit: EditText

    private val prefs by lazy { Prefs.of(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        infoText = findViewById(R.id.infoText)
        userIconsText = findViewById(R.id.userIconsText)
        phrasesEdit = findViewById(R.id.etPhrases)

        bindSwitch(R.id.switchEnabled, Prefs.ENABLED, true)
        bindSwitch(R.id.switchBubble, Prefs.BUBBLE, true)
        bindSwitch(R.id.switchDebug, Prefs.DEBUG_TOAST, false)

        phrasesEdit.setText(prefs.getString(Prefs.PHRASES, Prefs.DEFAULT_PHRASES))
        findViewById<Button>(R.id.btnSavePhrases).setOnClickListener {
            prefs.edit().putString(Prefs.PHRASES, phrasesEdit.text.toString()).apply()
            Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnProjection).setOnClickListener {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), reqProjection)
        }
        findViewById<Button>(R.id.btnProjectionStop).setOnClickListener {
            stopService(Intent(this, ProjectionService::class.java))
            Toast.makeText(this, "স্ক্রিন-ক্যাপচার বন্ধ করা হয়েছে", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnAddIcon).setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            i.addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(i, reqPick)
        }
        findViewById<Button>(R.id.btnClearIcons).setOnClickListener {
            TemplateStore.clearUser(this)
            bumpVersion()
            refresh()
        }

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
        }
    }

    private fun bindSwitch(id: Int, key: String, def: Boolean) {
        val sw = findViewById<Switch>(id)
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        statusText.text = if (enabled.contains(packageName))
            "সার্ভিস: চালু আছে ✅ (স্ক্রিনে সবুজ AC বোতাম দেখা যাবে)"
        else
            "সার্ভিস: বন্ধ ❌ (নিচের বাটন দিয়ে Accessibility-তে চালু করুন)"

        val capture = if (CaptureBridge.service != null) "স্ক্রিন-ক্যাপচার চালু ✅" else "স্ক্রিন-ক্যাপচার বন্ধ"
        val shot = if (Build.VERSION.SDK_INT >= 30)
            "এই ফোনে Accessibility স্ক্রিনশট আছে, আলাদা ক্যাপচার না চালালেও চলবে।"
        else
            "এই ফোনে Accessibility স্ক্রিনশট নেই, তাই নিচের \"স্ক্রিন-ক্যাপচার চালু করুন\" অবশ্যই চালাতে হবে।"
        infoText.text = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n$shot\n$capture"

        userIconsText.text = "অ্যাপের সঙ্গে দেওয়া ছবি: ${TemplateStore.bundledCount(this)} টি\n" +
            "পরে যোগ করা আইকন: ${TemplateStore.userCount(this)} টি"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == reqProjection) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, ProjectionService::class.java)
                i.putExtra("code", resultCode)
                i.putExtra("data", data)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                Toast.makeText(this, "স্ক্রিন-ক্যাপচার চালু হচ্ছে", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "অনুমতি দেওয়া হয়নি", Toast.LENGTH_SHORT).show()
            }
            return
        }

        if (requestCode != reqPick || resultCode != RESULT_OK) return
        val uri = data?.data ?: return

        val bmp: Bitmap? = try {
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        } catch (e: Exception) {
            null
        }
        if (bmp == null) {
            Toast.makeText(this, "ছবি পড়া যায়নি", Toast.LENGTH_SHORT).show()
            return
        }
        if (maxOf(bmp.width, bmp.height) > 300) {
            Toast.makeText(
                this,
                "ছবিটা অনেক বড়। শুধু আইকনটুকু টাইট করে ক্রপ করে দিন।",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val f = File(TemplateStore.dir(this), "user_" + System.currentTimeMillis() + ".png")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bumpVersion()
        refresh()
        Toast.makeText(this, "আইকন যোগ হয়েছে", Toast.LENGTH_SHORT).show()
    }

    private fun bumpVersion() {
        prefs.edit().putInt(Prefs.TEMPLATES_VERSION, prefs.getInt(Prefs.TEMPLATES_VERSION, 0) + 1).apply()
    }
}
