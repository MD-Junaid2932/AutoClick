package com.junaid.autoclose

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

enum class Kind {
    /** কোডে আঁকা আইকন: dp সাইজ ধরে খোঁজে */
    BUILTIN,

    /** ইউজারের যোগ করা ছবি: ছবির আসল মাপের আশেপাশে খোঁজে */
    NATIVE,

    /** অ্যাপের সঙ্গে দেওয়া ছবি: পর্দার প্রস্থের শতাংশ ধরে খোঁজে */
    RANGE
}

class IconTemplate(
    val name: String,
    val gray: Mat,
    val kind: Kind,
    val group: String,
    val minFrac: Double = 0.0,
    val maxFrac: Double = 0.0,
    val steps: Int = 8
)

data class Candidate(
    val name: String,
    val group: String,
    val score: Double,
    val x: Int,
    val y: Int
)

/**
 * স্ক্রিনশট আর আইকনের আউটলাইন (Canny edge) বের করে একাধিক সাইজে মেলায়।
 * প্রতিটি টেমপ্লেটের সবচেয়ে ভালো মিলটা ফেরত দেয় (সীমার নিচে হলেও, ডায়াগনস্টিকের জন্য)।
 */
class IconMatcher(private val templates: List<IconTemplate>) {

    private val ratio = 0.5   // গতির জন্য স্ক্রিনশট অর্ধেক করে নেওয়া হয়
    private val floor = 0.30  // এর নিচের স্কোর ধরা হয় না
    private val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(3.0, 3.0))

    fun scan(screen: Bitmap, density: Float, groups: Set<String>): List<Candidate> {
        val active = templates.filter { it.group in groups }
        if (active.isEmpty()) return emptyList()

        val rgba = Mat()
        Utils.bitmapToMat(screen, rgba)
        val gray = Mat()
        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        rgba.release()

        val small = Mat()
        Imgproc.resize(gray, small, Size(), ratio, ratio, Imgproc.INTER_AREA)
        gray.release()

        val edges = edgeMap(small)
        small.release()

        val sum = Mat()
        Imgproc.integral(edges, sum, CvType.CV_32S)

        val out = ArrayList<Candidate>()

        try {
        for (t in active) {
            var best: Candidate? = null

            for ((w, h) in sizesFor(t, density, screen.width)) {
                if (w < 8 || h < 8 || w >= edges.cols() || h >= edges.rows()) continue

                val resized = Mat()
                Imgproc.resize(
                    t.gray, resized, Size(w.toDouble(), h.toDouble()),
                    0.0, 0.0, Imgproc.INTER_AREA
                )
                val te = edgeMap(resized)
                resized.release()

                val tCount = Core.countNonZero(te)
                if (tCount < 10) {
                    te.release()
                    continue
                }

                val res = Mat()
                Imgproc.matchTemplate(edges, te, res, Imgproc.TM_CCOEFF_NORMED)
                Core.patchNaNs(res, 0.0)

                var tries = 0
                while (tries < 8) {
                    tries++
                    val mm = Core.minMaxLoc(res)
                    if (mm.maxVal < floor) break
                    val x = mm.maxLoc.x.toInt()
                    val y = mm.maxLoc.y.toInt()

                    // ফাঁকা বা অতিরিক্ত ভিড়ের জায়গায় ভুল মিল বাদ দেওয়ার জন্য যাচাই
                    val cnt = windowCount(sum, x, y, w, h)
                    if (cnt >= 0.35 * tCount && cnt <= 3.0 * tCount) {
                        val cur = best
                        if (cur == null || mm.maxVal > cur.score) {
                            best = Candidate(
                                t.name,
                                t.group,
                                mm.maxVal,
                                ((x + w / 2.0) / ratio).toInt(),
                                ((y + h / 2.0) / ratio).toInt()
                            )
                        }
                        break
                    } else {
                        // এই মিলের পুরো আশেপাশের এলাকা বাদ দিই, নাহলে পাশের পিক্সেলগুলোই বারবার আসে
                        val x0 = max(0, x - w / 2).toDouble()
                        val y0 = max(0, y - h / 2).toDouble()
                        val x1 = min(res.cols() - 1, x + w / 2).toDouble()
                        val y1 = min(res.rows() - 1, y + h / 2).toDouble()
                        Imgproc.rectangle(res, Point(x0, y0), Point(x1, y1), Scalar(-1.0), -1)
                    }
                }
                res.release()
                te.release()
            }

            val found = best
            if (found != null) out.add(found)
        }
        } finally {
            edges.release()
            sum.release()
        }
        return out
    }

    /** টেমপ্লেটের নেটিভ মেমরি ছেড়ে দেয় (নতুন করে লোড করার আগে ডাকা হয়) */
    fun release() {
        for (t in templates) t.gray.release()
    }

    private fun edgeMap(gray: Mat): Mat {
        val blur = Mat()
        Imgproc.GaussianBlur(gray, blur, Size(3.0, 3.0), 0.0)
        val e = Mat()
        Imgproc.Canny(blur, e, 60.0, 150.0)
        blur.release()
        Imgproc.dilate(e, e, kernel)
        return e
    }

    private fun windowCount(sum: Mat, x: Int, y: Int, w: Int, h: Int): Double {
        val a = sum.get(y, x)[0]
        val b = sum.get(y, x + w)[0]
        val c = sum.get(y + h, x)[0]
        val d = sum.get(y + h, x + w)[0]
        return (d - b - c + a) / 255.0
    }

    /** ছোট-করা স্ক্রিনশটের পিক্সেলে (w, h) জোড়ার তালিকা */
    private fun sizesFor(t: IconTemplate, density: Float, screenW: Int): List<Pair<Int, Int>> {
        val tw = t.gray.cols().toDouble()
        val th = t.gray.rows().toDouble()
        val longSide = max(tw, th)

        val longs: List<Double> = when (t.kind) {
            Kind.BUILTIN ->
                listOf(20.0, 28.0, 38.0, 52.0).map { it * density * ratio }

            Kind.NATIVE ->
                listOf(0.8, 1.0, 1.25).map { longSide * ratio * it }

            Kind.RANGE -> {
                val n = t.steps
                (0 until n).map { i ->
                    val f = t.minFrac * (t.maxFrac / t.minFrac).pow(i.toDouble() / (n - 1))
                    f * screenW * ratio
                }
            }
        }

        return longs.map { l ->
            val k = l / longSide
            Pair((tw * k).roundToInt(), (th * k).roundToInt())
        }
    }
}
