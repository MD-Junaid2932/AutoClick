package com.junaid.autoclose

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

enum class Kind {
    /** কোডে আঁকা আইকন: dp সাইজ ধরে খোঁজে */
    BUILTIN,

    /** ইউজারের যোগ করা ছবি: ছবির আসল মাপের আশেপাশে খোঁজে */
    NATIVE,

    /** অ্যাপের সঙ্গে দেওয়া ছবি: পর্দার প্রস্থের শতাংশ ধরে খোঁজে */
    RANGE
}

class IconTemplate(
    val name: String,
    val gray: Mat,
    val kind: Kind,
    val minFrac: Double = 0.0,
    val maxFrac: Double = 0.0,
    val steps: Int = 8
)

data class IconHit(val name: String, val score: Double, val x: Int, val y: Int)

/**
 * স্ক্রিনশট আর আইকনের আউটলাইন (Canny edge) বের করে একাধিক সাইজে মেলায়।
 * আউটলাইন ধরে মেলানো হয় বলে আইকন সাদা না কালো, তাতে সমস্যা হয় না।
 */
class IconMatcher(private val templates: List<IconTemplate>) {

    private val ratio = 0.5 // গতির জন্য স্ক্রিনশট অর্ধেক করে নেওয়া হয়
    private val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(3.0, 3.0))

    fun find(screen: Bitmap, density: Float, threshold: Double): IconHit? {
        val rgba = Mat()
        Utils.bitmapToMat(screen, rgba)
        val gray = Mat()
        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
        rgba.release()

        val small = Mat()
        Imgproc.resize(gray, small, Size(), ratio, ratio, Imgproc.INTER_AREA)
        gray.release()

        val edges = edgeMap(small)
        small.release()

        val sum = Mat()
        Imgproc.integral(edges, sum, CvType.CV_32S)

        var best: IconHit? = null

        for (t in templates) {
            for ((w, h) in sizesFor(t, density, screen.width)) {
                if (w < 8 || h < 8 || w >= edges.cols() || h >= edges.rows()) continue

                val resized = Mat()
                Imgproc.resize(
                    t.gray, resized, Size(w.toDouble(), h.toDouble()),
                    0.0, 0.0, Imgproc.INTER_AREA
                )
                val te = edgeMap(resized)
                resized.release()

                val tCount = Core.countNonZero(te)
                if (tCount < 10) {
                    te.release()
                    continue
                }

                val res = Mat()
                Imgproc.matchTemplate(edges, te, res, Imgproc.TM_CCOEFF_NORMED)
                Core.patchNaNs(res, 0.0)

                var tries = 0
                while (tries++ < 8) {
                    val mm = Core.minMaxLoc(res)
                    if (mm.maxVal < threshold) break
                    val x = mm.maxLoc.x.toInt()
                    val y = mm.maxLoc.y.toInt()

                    // ফাঁকা বা অতিরিক্ত ভিড়ের জায়গায় ভুল মিল বাদ দেওয়ার জন্য যাচাই
                    val cnt = windowCount(sum, x, y, w, h)
                    if (cnt >= 0.35 * tCount && cnt <= 3.0 * tCount) {
                        val cur = best
                        if (cur == null || mm.maxVal > cur.score) {
                            best = IconHit(
                                t.name,
                                mm.maxVal,
                                ((x + w / 2.0) / ratio).toInt(),
                                ((y + h / 2.0) / ratio).toInt()
                            )
                        }
                        break
                    } else {
                        res.put(y, x, -1.0)
                    }
                }
                res.release()
                te.release()
            }
        }

        edges.release()
        sum.release()
        return best
    }

    private fun edgeMap(gray: Mat): Mat {
        val blur = Mat()
        Imgproc.GaussianBlur(gray, blur, Size(3.0, 3.0), 0.0)
        val e = Mat()
        Imgproc.Canny(blur, e, 60.0, 150.0)
        blur.release()
        Imgproc.dilate(e, e, kernel)
        return e
    }

    private fun windowCount(sum: Mat, x: Int, y: Int, w: Int, h: Int): Double {
        val a = sum.get(y, x)[0]
        val b = sum.get(y, x + w)[0]
        val c = sum.get(y + h, x)[0]
        val d = sum.get(y + h, x + w)[0]
        return (d - b - c + a) / 255.0
    }

    /** ছোট-করা স্ক্রিনশটের পিক্সেলে (w, h) জোড়ার তালিকা */
    private fun sizesFor(t: IconTemplate, density: Float, screenW: Int): List<Pair<Int, Int>> {
        val tw = t.gray.cols().toDouble()
        val th = t.gray.rows().toDouble()
        val longSide = max(tw, th)

        val longs: List<Double> = when (t.kind) {
            Kind.BUILTIN ->
                listOf(20.0, 28.0, 38.0, 52.0).map { it * density * ratio }

            Kind.NATIVE ->
                listOf(0.8, 1.0, 1.25).map { longSide * ratio * it }

            Kind.RANGE -> {
                val steps = t.steps
                (0 until steps).map { i ->
                    val f = t.minFrac * (t.maxFrac / t.minFrac).pow(i.toDouble() / (steps - 1))
                    f * screenW * ratio
                }
            }
        }

        return longs.map { l ->
            val k = l / longSide
            Pair((tw * k).roundToInt(), (th * k).roundToInt())
        }
    }
}
