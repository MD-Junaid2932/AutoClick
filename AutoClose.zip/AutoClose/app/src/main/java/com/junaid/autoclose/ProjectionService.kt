package com.junaid.autoclose

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

/** চালু থাকা ProjectionService-টা AutoCloseService এখান থেকে খুঁজে নেয় */
object CaptureBridge {
    @Volatile
    var service: ProjectionService? = null
}

/**
 * MediaProjection দিয়ে স্ক্রিনের ছবি নেয়। Android 10 বা পুরোনো ফোনে (যেখানে
 * Accessibility স্ক্রিনশট নেই) এটাই একমাত্র উপায়। নতুন ফোনেও চালু করা যায়।
 *
 * সবসময় সর্বশেষ ফ্রেমটা ধরে রাখা হয় (listener দিয়ে), যাতে grab() করলে
 * কয়েক সেকেন্ড আগের ছবি না এসে বর্তমান স্ক্রিনের ছবি আসে।
 */
class ProjectionService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val lock = Any()

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var held: Image? = null
    private var w = 0
    private var h = 0
    private var dpi = 0

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("data", Intent::class.java)
        } else {
            intent?.getParcelableExtra("data")
        }

        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        // আগের প্রজেক্শন চালু থাকলে আগে পরিষ্কার করে নেওয়া
        release()

        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            val cb = object : MediaProjection.Callback() {
                override fun onStop() {
                    handler.post {
                        release()
                        stopSelf()
                    }
                }
            }
            p.registerCallback(cb, handler)
            projection = p
            projectionCallback = cb
            setupDisplay()
            CaptureBridge.service = this
        } catch (e: Exception) {
            Log.e("AutoClose", "projection start failed", e)
            release()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun startAsForeground() {
        val channelId = "autoclose_capture"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "Screen capture", NotificationManager.IMPORTANCE_LOW)
            )
            builder = Notification.Builder(this, channelId)
        } else {
            builder = Notification.Builder(this)
        }
        val n = builder
            .setContentTitle("Auto Close")
            .setContentText("স্ক্রিন দেখা চলছে")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun realMetrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getRealMetrics(dm)
        return dm
    }

    /** নতুন ফ্রেম এলেই সেটা ধরে রাখে, আগেরটা বন্ধ করে দেয় */
    private fun attachListener(r: ImageReader) {
        r.setOnImageAvailableListener({ rd ->
            try {
                val img = rd.acquireLatestImage()
                if (img != null) {
                    synchronized(lock) {
                        held?.close()
                        held = img
                    }
                }
            } catch (e: Exception) {
                Log.e("AutoClose", "frame listener", e)
            }
        }, handler)
    }

    private fun setupDisplay() {
        val dm = realMetrics()
        w = dm.widthPixels
        h = dm.heightPixels
        dpi = dm.densityDpi
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        attachListener(r)
        reader = r
        display = projection?.createVirtualDisplay(
            "autoclose", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, handler
        )
    }

    /** স্ক্রিন ঘুরলে (landscape/portrait) আকার ঠিক করে নেয় */
    private fun ensureSize() {
        val dm = realMetrics()
        if (dm.widthPixels == w && dm.heightPixels == h) return
        w = dm.widthPixels
        h = dm.heightPixels
        dpi = dm.densityDpi
        val newReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        attachListener(newReader)
        val vd = display
        if (vd != null) {
            vd.resize(w, h, dpi)
            vd.surface = newReader.surface
        }
        val old = reader
        reader = newReader
        synchronized(lock) {
            held?.close()
            held = null
        }
        try {
            old?.close()
        } catch (e: Exception) {
        }
    }

    /** বর্তমান স্ক্রিনের একটা কপি দেয় (এখনো কোনো ফ্রেম না এলে null) */
    fun grab(): Bitmap? {
        return try {
            ensureSize()
            synchronized(lock) { convertHeld() }
        } catch (e: Exception) {
            Log.e("AutoClose", "grab failed", e)
            null
        }
    }

    /** lock ধরা অবস্থায় ডাকতে হবে */
    private fun convertHeld(): Bitmap? {
        val img = held ?: return null
        val plane = img.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * img.width
        val full = Bitmap.createBitmap(
            img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888
        )
        full.copyPixelsFromBuffer(plane.buffer)
        if (rowPadding == 0) return full
        val cropped = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        full.recycle()
        return cropped
    }

    private fun release() {
        try {
            display?.release()
        } catch (e: Exception) {
        }
        display = null

        synchronized(lock) {
            try {
                held?.close()
            } catch (e: Exception) {
            }
            held = null
        }
        try {
            reader?.close()
        } catch (e: Exception) {
        }
        reader = null

        val p = projection
        val cb = projectionCallback
        projection = null
        projectionCallback = null
        if (p != null) {
            try {
                // আগে callback সরিয়ে নিই, নাহলে stop() আবার release()+stopSelf() চালিয়ে দেবে
                if (cb != null) p.unregisterCallback(cb)
                p.stop()
            } catch (e: Exception) {
            }
        }
        if (CaptureBridge.service === this) CaptureBridge.service = null
    }

    override fun onDestroy() {
        release()
        super.onDestroy()
    }
}
