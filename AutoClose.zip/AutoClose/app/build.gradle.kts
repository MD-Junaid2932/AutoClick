plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.junaid.autoclose"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.junaid.autoclose"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"

        // অ্যাপের সাইজ কমানোর জন্য শুধু ফোনের সাধারণ আর্কিটেকচার
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // ছবি মেলানোর জন্য (template matching)
    implementation("org.opencv:opencv:4.9.0")
}
